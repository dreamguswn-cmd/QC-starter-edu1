# pytest 기능 테스트 판정 결과표

- 생성 시각: 2026-07-08 16:38:36
- 총 테스트: 29건 / PASS 29건 / FAIL 0건 / SKIP 0건
- 통과율: 100.0%

| 테스트 수준 | 파일 | 테스트 | 판정 | 소요(ms) |
| --- | --- | --- | --- | --- |
| test_agent_api.py | test_agent_api.py | test_ask_response_schema | PASS | 48.9 |
| test_agent_api.py | test_agent_api.py | test_ask_happy_case_education_hours | PASS | 9.9 |
| test_agent_api.py | test_agent_api.py | test_ask_happy_case_attendance_rule | PASS | 26.8 |
| test_agent_api.py | test_agent_api.py | test_ask_happy_case_completion_rate | PASS | 24.5 |
| test_agent_api.py | test_agent_api.py | test_ask_happy_case_job_support | PASS | 24.2 |
| 장애 실습 엔드포인트(/fault-lab) 테스트 — normal · delay · error500 · timeout 시나리오. | test_fault_lab.py | test_normal_response | PASS | 28.9 |
| 장애 실습 엔드포인트(/fault-lab) 테스트 — normal · delay · error500 · timeout 시나리오. | test_fault_lab.py | test_delay_response | PASS | 1063.9 |
| 장애 실습 엔드포인트(/fault-lab) 테스트 — normal · delay · error500 · timeout 시나리오. | test_fault_lab.py | test_error500_response | PASS | 15.4 |
| 장애 실습 엔드포인트(/fault-lab) 테스트 — normal · delay · error500 · timeout 시나리오. | test_fault_lab.py | test_timeout_response | PASS | 1006.5 |
| test_health.py | test_health.py | test_health_status_ok | PASS | 40.1 |
| test_health.py | test_health.py | test_health_service_name | PASS | 4.6 |
| test_health.py | test_health.py | test_metrics_endpoint_exposed | PASS | 21.8 |
| test_negative_cases.py | test_negative_cases.py | test_empty_question_returns_422 | PASS | 6.8 |
| test_negative_cases.py | test_negative_cases.py | test_invalid_mode_returns_422 | PASS | 8.5 |
| test_negative_cases.py | test_negative_cases.py | test_question_too_long_returns_422 | PASS | 4.0 |
| test_negative_cases.py | test_negative_cases.py | test_safety_filter_violence_keyword | PASS | 0.2 |
| test_negative_cases.py | test_negative_cases.py | test_safety_filter_threat_keyword | PASS | 0.2 |
| test_negative_cases.py | test_negative_cases.py | test_safety_filter_harassment_keyword | PASS | 0.3 |
| test_negative_cases.py | test_negative_cases.py | test_out_of_scope_weather | PASS | 0.3 |
| test_negative_cases.py | test_negative_cases.py | test_out_of_scope_instructor_name | PASS | 0.2 |
| test_quality_pipeline.py | test_quality_pipeline.py | test_rule_validator_pass | PASS | 0.2 |
| test_quality_pipeline.py | test_quality_pipeline.py | test_rule_validator_fail | PASS | 0.3 |
| test_quality_pipeline.py | test_quality_pipeline.py | test_test_cases_json_exists | PASS | 0.4 |
| test_quality_pipeline.py | test_quality_pipeline.py | test_test_cases_structure | PASS | 24.8 |
| test_quality_pipeline.py | test_quality_pipeline.py | test_pipeline_rule_mode_returns_all_cases | PASS | 21784.4 |
| test_quality_pipeline.py | test_quality_pipeline.py | test_pipeline_rule_mode_pass_7 | PASS | 18090.0 |
| test_quality_pipeline.py | test_quality_pipeline.py | test_pipeline_result_has_required_keys | PASS | 18125.5 |
| test_quality_pipeline.py | test_quality_pipeline.py | test_reports_generated | PASS | 18438.9 |
| test_quality_pipeline.py | test_quality_pipeline.py | test_evaluation_json_valid | PASS | 18114.4 |
